Jeu du tarot africain -- Projet d'informatique S2
====================================================

Pour lancer le jeu, simplement exécuter le fichier "Tarot_Africain.py".

4 fichiers Python sont livrés :
- Tarot_Africain.py : le programme principal
- Joueurs.py : module de gestion des joueurs (humain et bot)
- TA_Bots.py : module permettant le jeu de la machine (calcul des coups du bot)
- test_Tarot_Africain.py : contient les tests unitaires

====================================================

Le code source est également disponible sur GitHub : https://github.com/thomas40510/ProjetInfoS2