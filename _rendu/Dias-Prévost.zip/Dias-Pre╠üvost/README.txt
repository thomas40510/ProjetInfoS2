Projet Informatique - Tarot Africain
Dias Nicolas - Prévost Thomas
FISE24 UE2.4
Pour lancer ce projet, vous pouvez:
-soit le lancer sans IHM, et interagit en textuel dans la console, en faisant tourner le fichier Tarot_Africain
-soit le lancer avec IHM, en faisant tourner le fichier Tarot_Africain_UI
Vous pouvez aussi vérifier les tests en lançant test_Tarot_Africain